import React from 'react';
import { Link } from 'react-router-dom';
import { useFavorites } from '../context/FavoritesContext';
import TrackCard from '../components/TrackCard';

export default function Favorites({ onPlay }) {
  const { favorites } = useFavorites();

  return (
    <div className="favorites-page">
      <div className="page-header favorites-header">
        <div className="page-header-icon">♥</div>
        <div>
          <h1>Избранное</h1>
          <p className="page-subtitle">{favorites.length} треков</p>
        </div>
      </div>

      {favorites.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">♡</div>
          <h2>Твоё избранное пусто</h2>
          <p className="empty-hint">Добавляй любимые треки, чтобы слушать их позже</p>
          <Link to="/search" className="cta-btn">
            НАЙТИ МУЗЫКУ
          </Link>
        </div>
      ) : (
        <div className="track-grid">
          {favorites.map((track) => (
            <TrackCard key={track.id} track={track} onPlay={onPlay} />
          ))}
        </div>
      )}
    </div>
  );
}
