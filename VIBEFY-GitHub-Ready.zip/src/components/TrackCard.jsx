import React from 'react';
import { useFavorites } from '../context/FavoritesContext';

function formatDuration(ms) {
  if (!ms) return '';
  const sec = Math.floor(ms / 1000);
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

export default function TrackCard({ track, onPlay }) {
  const { isFavorite, toggleFavorite } = useFavorites();
  const favorite = isFavorite(track.id);

  const image =
    track.image ||
    track.album?.images?.[0]?.url ||
    'https://via.placeholder.com/300';

  const artist =
    track.artists?.map((a) => a.name).join(', ') ||
    track.artist ||
    'Unknown Artist';

  const explicit = track.contentRating === 'EXPLICIT';

  return (
    <div className="track-card">
      <div className="track-image-container" onClick={() => onPlay?.(track)}>
        <img src={image} alt={track.name} className="track-image" />
        <div className="play-overlay">▶</div>
        <button
          className={`track-fav-btn ${favorite ? 'active' : ''}`}
          onClick={(e) => {
            e.stopPropagation();
            toggleFavorite(track);
          }}
          aria-label="Favorite"
        >
          {favorite ? '♥' : '♡'}
        </button>
      </div>
      <div className="track-info">
        <div className="track-title">
          {explicit && <span className="explicit-badge">E</span>}
          {track.name}
        </div>
        <div className="track-artist">{artist}</div>
        {track.duration_ms > 0 && (
          <div className="track-duration">{formatDuration(track.duration_ms)}</div>
        )}
      </div>
    </div>
  );
}
