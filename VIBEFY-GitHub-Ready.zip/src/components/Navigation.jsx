import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const links = [
  { to: '/', icon: '⌂', label: 'Главная' },
  { to: '/search', icon: '⌕', label: 'Поиск' },
  { to: '/favorites', icon: '♥', label: 'Избранное' },
  { to: '/recommendations', icon: '✦', label: 'Рекомендации' }
];

export default function Navigation() {
  const location = useLocation();

  return (
    <nav className="navigation">
      <div className="nav-brand">
        <span className="brand-icon">◆</span>
        <span className="brand-text">VIBEFY</span>
      </div>
      <div className="nav-links">
        {links.map((link) => (
          <Link
            key={link.to}
            to={link.to}
            className={`nav-link ${location.pathname === link.to ? 'active' : ''}`}
          >
            <span className="nav-icon">{link.icon}</span>
            <span>{link.label}</span>
          </Link>
        ))}
      </div>
    </nav>
  );
}
