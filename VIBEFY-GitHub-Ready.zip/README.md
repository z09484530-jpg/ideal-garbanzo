# VIBE FY

1:1 клон https://app-flame-two-50.vercel.app

Музыка: ырды бассаң → төмөндө Spotify player → Play → ыр ойнойт.

## Тез старт

```bash
npm install
npm run dev
```

http://localhost:5173/search

## GitHub'га жүктөө (3 буйрук)

```bash
# 1. GitHub'да жаңы repo түз (бош) же:
gh repo create vibefy --public --source=. --remote=origin --push

# Же кол менен:
git init
git add .
git commit -m "VIBE FY - Spotify music app"
git branch -M main
git remote add origin https://github.com/СЕНИН_USERNAME/vibefy.git
git push -u origin main
```

## Vercel (сылка чыгарат)

GitHub'га жүктөгөндөн кийин:
1. https://vercel.com/new
2. Repo танда → Deploy

Же:
```bash
npx vercel --prod
```

## API

RapidAPI Spotify23 ключ `src/api.js` ичинде.
